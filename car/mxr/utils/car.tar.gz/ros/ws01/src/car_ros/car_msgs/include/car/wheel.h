#ifndef CAR_WHEEL_H
#define CAR_WHEEL_H

#include <car_msgs/Wheel.h>

namespace car
{
class Wheel : public car_msgs::Wheel
{
public:
  Wheel();
};
};
#endif  // CAR_WHEEL_H
