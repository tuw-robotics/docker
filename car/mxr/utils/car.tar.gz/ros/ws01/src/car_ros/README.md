# car_ros
This is a ROS meta pkg for the mx-car
## git
The project includes sub repositories, therefore you have to use the following command to clone everything
```
git clone git@github.com:mx-car/car_ros.git
```
The command above will clone a specific version of the sub-repository. 
