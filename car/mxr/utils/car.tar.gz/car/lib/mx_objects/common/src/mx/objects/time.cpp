
#include <mx/objects/time.h>

using namespace mx::objects;

Time Time::OFFSET ( 0,0 );
uint32_t Time::OFFSET_MICROS(0);

