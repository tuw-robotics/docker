#include "gtest/gtest.h"
#include <mx/serial/uart.h>

TEST(Time, Duration)
{
  EXPECT_EQ(2, 1 + 1);
}

