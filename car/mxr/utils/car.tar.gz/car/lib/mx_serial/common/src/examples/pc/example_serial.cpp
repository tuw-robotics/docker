/**
 * @author Markus Bader <markus.bader@mx-robotics.com>
 * @date 15th of February 2021
 **/

#include <csignal>
#include <unistd.h>
#include <iostream>
#include <mx/pb/pb_handler.h>
#include <boost/program_options.hpp>
#include "mx/pb/objects2d.pb.h"
#include <libserial/SerialPort.h>


volatile std::sig_atomic_t gSignalStatus;
void signal_handler(int signal)
{
    gSignalStatus = signal;
}

struct Parameters
{
    static int loop;
    std::string port;
    int baudrate;
};

Parameters params;
int main(int argc, char *argv[])
{

    uint8_t bufferOut[128];
    memset(bufferOut, '-', 128);
    uint8_t bufferIn[128];
    memset(bufferIn, '-', 128);
    size_t message_length;
    bool status;

    std::signal(SIGINT, signal_handler);

    namespace po = boost::program_options;
    po::options_description desc("Allowed Parameters");
    desc.add_options()("help", "get this help message")("port,m", po::value<std::string>(&params.port)->default_value("/dev/ttyACM0"), "serial port")("baudrate,b", po::value<int>(&params.baudrate)->default_value(115200), "baudrate");

    po::variables_map vm;
    try
    {
        po::store(po::parse_command_line(argc, argv, desc), vm);
    }
    catch (const std::exception &ex)
    {
        std::cout << desc << std::endl;
        ;
        exit(1);
    }
    po::notify(vm);

    if (vm.count("help"))
    {
        std::cout << desc << std::endl;
        exit(1);
    }

    
    // Instantiate a SerialPort object.
    LibSerial::SerialPort serial_port ;

    try
    {
        // Open the Serial Port at the desired hardware port.
        serial_port.Open(params.port.c_str()) ;
    }
    catch (const LibSerial::OpenFailed&)
    {
        std::cerr << "The serial port did not open correctly." << std::endl ;
        return EXIT_FAILURE ;
    }

    // Set the baud rate of the serial port.
    serial_port.SetBaudRate(LibSerial::BaudRate::BAUD_115200) ;

    // Set the number of data bits.
    serial_port.SetCharacterSize(LibSerial::CharacterSize::CHAR_SIZE_8) ;

    // Turn off hardware flow control.
    serial_port.SetFlowControl(LibSerial::FlowControl::FLOW_CONTROL_NONE) ;

    // Disable parity.
    serial_port.SetParity(LibSerial::Parity::PARITY_NONE) ;
    
    // Set the number of stop bits.
    serial_port.SetStopBits(LibSerial::StopBits::STOP_BITS_1) ;
    
    
    //Uart uart(params.serial.port, params.serial.baudrate);
    Point2d point = Point2d_init_zero;
    mx::pb::Message msg;
    mx::pb::PBHandler handler;
    msg.header.type = 2;
    while (gSignalStatus == 0)
    {
        char *out;
        point.x = 9;
        out = handler.encode(Point2d_fields, point, msg);
        //uart.write(out, msg.header.size);
        LibSerial::DataBuffer db;
        serial_port.Write(handler.copy_to(msg, db));
        std::cout << "out: size = " << msg.header.size << " type = " << msg.header.type << ": x = " << point.x << ", y = " << point.y << std::endl;
        sleep(1);
        mx::pb::Header header;
        if( handler.check_for_new_msgs(header, serial_port).type != 0 ){
            db.resize(header.size);
            serial_port.Read(db, db.size() );
            handler.decode(Point2d_fields, point, db);
            std::cout << "in : size = " << header.size << " type = " << header.type << ": x = " << point.x << ", y = " << point.y << std::endl;
                        
        }
        
    }


    return 0;
}
