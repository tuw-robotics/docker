#ifndef MX_PB_MESSAGE_H
#define	MX_PB_MESSAGE_H

#include <pb_encode.h>
#include <pb_decode.h>
#include <vector>

namespace mx {
namespace pb {

struct Header {
    uint16_t size;
    uint16_t type;
};
struct Message {
    Header header;
    pb_byte_t buffer[0xFF];
    size_t size() {
        return header.size + sizeof(Header);
    }
    char *ptr(){
        return (char*) this;
    }
};
    
struct PBHandler {

    template <class PBObj>
    char *encode(const pb_msgdesc_t *fields, PBObj &des, Message &message) {
        pb_ostream_t stream = pb_ostream_from_buffer(message.buffer, sizeof(message.buffer));
        bool status = pb_encode(&stream, fields, &des);
        if(!status) {
            message.header.type = 0;
        }
        message.header.size = stream.bytes_written;
        return (char*) &message;
    };

    template <class PBObj>
    char *decode(const pb_msgdesc_t *fields, PBObj &des, Message &message) {
        pb_istream_t stream = pb_istream_from_buffer((const pb_byte_t*) message.buffer, message.header.size);
        bool status = pb_decode(&stream, fields, &des);
        if(!status) {
            message.header.type = 0;
        }
        return (char*) &message;
    };
    template <class PBObj>
    bool decode(const pb_msgdesc_t *fields, PBObj &src, std::vector<uint8_t> &message) {
        pb_istream_t stream = pb_istream_from_buffer((const pb_byte_t*) &message[0], message.size());
        return pb_decode(&stream, fields, &src);
    };
    
    std::vector<uint8_t> &copy_to(Message &src, std::vector<uint8_t> &des) {
        uint8_t *p = (uint8_t*) &src;
        des.resize(src.size());
        for(auto &v: des) v = *p++;
        return des;
    };

#if defined(__amd64__)
    template <class Serial>
    Header &check_for_new_msgs(Header &header, Serial &serial)
    {
        header.type = 0;
        if( serial.IsDataAvailable() ) {
            char *buffer = (char *)&header;
            for(size_t i = 0; i < sizeof(Header); i++)  {
                serial.ReadByte(buffer[i]);
            }
        }
        return header;
    }
#else
    template <class Serial>
    bool check_for_new_msgs(Header &header, Serial &serial)
    {
        size_t i;
        char *buffer = (char *)&header;
        for (i = 0; i < sizeof(Header); i++)
        {
            if (serial.available()) buffer[i] = serial.read();
            else break;
        }
        return (i == sizeof(Header));
    }
#endif
};
};
};
#endif  //MX_PB_MESSAGE_H
