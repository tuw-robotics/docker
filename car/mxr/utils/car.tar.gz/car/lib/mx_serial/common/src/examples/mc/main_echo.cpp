/*
  Blink
  Turns on an LED on for one second, then off for one second, repeatedly.

  This example code is in the public domain.
 */

#include <Wire.h>        // Only needed for Arduino 1.6.5 and earlier
#include "SSD1306Wire.h" // legacy: #include "SSD1306.h"
#include <Arduino.h>
#include <stdio.h>
#include <mx/pb/pb_handler.h>
#include <mx/pb/objects2d.pb.h>

#define MAX_BUFFER_SIZE 0xFF
unsigned char buffer[MAX_BUFFER_SIZE];
char bufferOut[MAX_BUFFER_SIZE];
char dbuffer[MAX_BUFFER_SIZE];
SSD1306Wire display(0x3c, SDA, SCL); // ADDRESS, SDA, SCL  -  SDA and SCL usually populate
uint16_t loop_count = 0;
uint16_t msg_count = 0;
mx::pb::PBHandler handler;

int led = 13;
void setup()
{
  pinMode(led, OUTPUT); // wait for a second
  digitalWrite(led, LOW);
  display.init();

  display.setFont(ArialMT_Plain_16);
  display.flipScreenVertically();
  display.setTextAlignment(TEXT_ALIGN_LEFT);
  display.drawString(0, 0, "Hallo");
  display.display();
  Serial.begin ( 115200 );
  while (!Serial)
    display.drawString(0, 16, "Connected");
  display.display();
  buffer[0] = '\0';
}


void loop()
{

  Point2d point = Point2d_init_zero;
  mx::pb::Message msg;
  if (handler.check_for_new_msgs(msg.header, Serial))
  {
    msg_count++;
    Serial.readBytes((char*) msg.buffer, msg.header.size);
    handler.decode(Point2d_fields, point, msg);
    sprintf(dbuffer, "%2d, %2d, x=%2d, y=%2d", msg.header.size, msg.header.type, (int) point.x, (int) point.y);
    display.clear();
    display.drawString(0, 16, dbuffer);
    display.display();
    if (true)
    {
      point.y = point.x;
      char *out = handler.encode(Point2d_fields, point, msg);
      Serial.write(out, msg.size());
    }
  }
  loop_count++;
}
